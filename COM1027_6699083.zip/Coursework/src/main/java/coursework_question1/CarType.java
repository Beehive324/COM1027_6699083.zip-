package coursework_question1;

public enum CarType {
	
	MANUAL, AUTOMATIC
}
