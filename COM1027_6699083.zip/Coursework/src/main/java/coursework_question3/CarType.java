package coursework_question3;

public enum CarType {
	
	MANUAL, AUTOMATIC
}
