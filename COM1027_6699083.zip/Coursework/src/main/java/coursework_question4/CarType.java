package coursework_question4;

public enum CarType {
	
	MANUAL, AUTOMATIC
}
