package coursework_question4;

public enum Condition {
	
	NEW, USED

}
